  /*
 * File:        dac.c
 * Purpose:     Provide DAC routines
 *
 * Notes:		
 *
 */
 
#include "MK64F12.h"
#include "dac.h"